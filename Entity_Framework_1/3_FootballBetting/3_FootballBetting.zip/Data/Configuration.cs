﻿namespace _3_FootballBetting.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-JN606AP\\SQLEXPRESS;" +
                                               "Database=StudentSystem;" +
                                               "Integrated Security=true";
    }
}
