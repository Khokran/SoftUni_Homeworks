﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-JN606AP\\SQLEXPRESS;
                                                  Database=TeisterMask;
                                                  Trusted_Connection=True";
    }
}
