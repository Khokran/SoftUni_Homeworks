﻿namespace TeisterMask.Data
{
    public class LabelType
    {

    }
}
