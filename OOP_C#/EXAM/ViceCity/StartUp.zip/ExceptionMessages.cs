﻿namespace ViceCity
{
    public static class ExceptionMessages
    {
        public const string NullName = "Player's name cannot be null or a whitespace!";
    }
}   