﻿namespace ViceCity.IO.Contracts
{
    interface IReader
    {
        string ReadLine();
    }
}
