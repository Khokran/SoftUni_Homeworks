﻿using System;

namespace StackOfStrings
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
