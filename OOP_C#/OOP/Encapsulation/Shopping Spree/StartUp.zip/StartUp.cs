﻿using Shopping_Spree.Core;

namespace Shopping_Spree
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
